import packaging
from setuptools import setup

setup(
    name="paquetecalculos",
    version="1.0",
    description="paquete de redondeo y potencia",
    author="JAP",
    author_email="japperez@gmail.com",
    packages=["paquete_calculos", "paquete_calculos.calculos_complicados"]


)