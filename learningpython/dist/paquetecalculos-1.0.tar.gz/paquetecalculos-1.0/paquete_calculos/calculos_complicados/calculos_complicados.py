def potencia(base,exponente):
    print(f"el resultasdo es : {base**exponente}")

def redondear(numero):
    print(f"el resultado de la suma es: {round(numero)}")