def sumar(a,b):
    print(f"el resltado es: {a+b}")

def restar(a,b):
    print(f"el resltado es: {a-b}")

def multiplicar(a,b):
    print(f"el resltado es: {a*b}")

def dividir(a,b):
    print(f"el resultado es: {a/b}")

